
class JandyClassError(Exception):
    pass

