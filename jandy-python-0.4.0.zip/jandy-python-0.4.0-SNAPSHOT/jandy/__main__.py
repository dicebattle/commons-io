
if __name__ == '__main__':
    from jandy.main import main
    main()
